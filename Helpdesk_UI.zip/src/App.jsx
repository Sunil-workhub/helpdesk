import { useState } from "react";
import AppRoutes from "./routes/AppRoutes.jsx";

function App() {
  return (
    <>
      <AppRoutes />
    </>
  );
}

export default App;
